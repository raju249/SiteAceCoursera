(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['hot-code-push'] = {};

})();

//# sourceMappingURL=hot-code-push.js.map
